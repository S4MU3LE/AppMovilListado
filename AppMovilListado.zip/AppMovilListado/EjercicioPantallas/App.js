import React from "react";
import MainContainer from "./componentes/MainContainer";
function App() {
return (
    
    <MainContainer/>

    // seguir los pasos de react native doc. para iniciar la app en movil a  traves de cable de carga
   
)
}
export default App;